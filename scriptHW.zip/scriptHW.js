function getSumOfSequence()
{
    const args = [...arguments];
    let numequal = 0;
    if (args.length === 0)
    {
        return 0;
    }
    else
    {
        let result = 0;
        for(let i = 0; i < args.length; i++)
        {
            if (i === 0 || i === args.length-1)
            {
                result += args[i];
            }
            else
            {
                continue;
            }
        }
        return result;
    }
}

const arr1 = [1, 2, 3, 4, 5];

console.log(getSumOfSequence(...arr1));

function getDivisorsCount(number = 1)
{
    const resultArray = [];
    if (number < 0 || !Number.isInteger(number))
    {
        alert("number должен быть целым числом и больше нуля!");
    }
    else
    {
        for (let i = number; i > 0; i--)
        {
            number % i === 0 ? resultArray.push(i) : i;
        }
        console.log(`Делители числа ${number}: ${resultArray.join(", ")}`);
    }
}

getDivisorsCount(4);
getDivisorsCount(5);
getDivisorsCount(12);

const person = 
{
    name: 'Максим',
    age: 25,
    profession: 'Frontend-developer',
    getInfo: function() 
    {
        console.log(`Меня зовут ${this.name}. Мне ${this.age} лет. Я - ${this.profession}.`);
    }
};

person.getInfo();