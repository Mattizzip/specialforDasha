//1 Задание - Конвертер валют

function USDToEuroConverter(usdValue)
{
    const euroRate = 1.09; //Курс 1 Евро к доллару на 19.11.2023
    let euro = usdValue / euroRate;
    return euro.toFixed(2);
}

//Вызов функции
let userMoney = prompt("Введите сумму денег в долларах");

if (userMoney === "" || isNaN(userMoney) || userMoney === null || userMoney === undefined)
{
    console.log("INVALID VALUE")
}
else
{
    alert(`${userMoney} $ = ${USDToEuroConverter(Number(userMoney))} €`)
}

//2 Задание
let k = 0;
for(let i = 1000;; i /= 2)
{
    k++;
    if(i < 50)
    {
        console.log(`Результат: ${i}\nЧисло делений: ${k}`);
        break;
    }
}

//3 Задание
let sum = 0;
for(let i = 0; i <= 100; i++)
{
    sum += i;
}

alert(`Результат суммы от 0 до 100 составляет ${sum}`);

//4 задание
let userYear = prompt("Введите год вашего рождения");

if (userYear === "" || isNaN(userYear) || userYear === null || userYear === undefined)
{
    console.log("INVALID VALUE")
}
else
{
    for(let i = Number(userYear); i < 2023; i++)
    {
        console.log(`в  ${i} году было ${i - Number(userYear)} лет`);   
    }
}

//5 Задание
let userM = prompt("Введите баланс");
let chocPrice = prompt("Введите стоимость шоколадки");

if (userM === "" || isNaN(userM) || userM === null || userM === undefined && chocPrice === "" || isNaN(chocPrice) || chocPrice === null || chocPrice === undefined)
{
    console.log("INVALID VALUE")
}
else
{
    let chocEqual = 0;
    for(let i = Number(userM); i >= 0; i -= chocPrice)
    {
        //Доделать
        if (i < Number(chocPrice))
        {
            alert(`Имея ${userM} $ вы можете купить ${chocEqual} шоколадок. После у вас останется ${userM - chocEqual * chocPrice}`);
            break;
        }
        else
        {
            chocEqual++;
        }
    }
}